"""
Colleciton of custom error types.
"""


class InvalidFileListLengthError(Exception):
    """
    Error type for file list length == 0
    """
